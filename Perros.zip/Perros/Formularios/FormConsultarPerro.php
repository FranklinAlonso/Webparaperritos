<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta de Perros</title>
    <link rel="stylesheet" href="../css/estilos_2.css">
</head>
<body>
    <header class="header-4">
        <div class="navigation">
            <?php
                $usuario = $_GET['variable'];
                $conn = mysqli_connect("localhost", "root","", "perrodb");
                if (!$conn) {
                    die("Error de conexion: " . mysqli_connect_error());
                }
                $query = mysqli_query($conn,"SELECT * FROM persona WHERE usuario = '".$usuario."'");
                $row = mysqli_fetch_array($query);
                echo "<a class=\"logo\"> Usuario: ".$row['Nombre'].", ".$row['Apellido']." </a>";
            ?>
                <ul>
                    <li><a href="../Sesion/indexUsuario.php">Inicio</a></li>
                    <li><a href="FormRegistrarPerro.php?variable=<?php echo $usuario; ?>">Registrar</a></li>
                    <li><a href="#Contacto">Contacto</a></li>
                </ul>
        </div>
        <section class="contenido">
            <h1>Tus Mejores Amigos</h1>
            <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.
                Quisquam cum distinctio perferendis sunt tenetur natus recusandae.</p>
        </section>
    </header>
    <div class="curva"></div>
    <section class="informacion">
        <div class="resena">
            <div class="card-reu">
                <?php
                    //conexion a la Base de datos (Servidor,usuario,password)
                    $conn = mysqli_connect("localhost", "root","", "perrodb");
                    if (!$conn) {
                        die("Error de conexion: " . mysqli_connect_error());
                    }
                    //(nombre de la base de datos, $enlace) mysql_select_db("RelocaDB",$link);
                    //capturando datos
                    $v2 = $row['DNI'];
                    //conuslta SQL
                    $sql = "select * from perro where DNI_Persona like '".$v2."'";
                    $result = mysqli_query($conn, $sql);
                    //cuantos reultados hay en la busqueda
                    $num_resultados = mysqli_num_rows($result);
                    //echo "<p>Número de perro encontrados: ".$num_resultados."</p>";
                    //mostrando informacion de los perros y detalle
                    if($num_resultados < 1){
                        echo "<h1 class=\"titulo-perro\">Aun no tienes amigos perrunos :(</h1>";
                    }else{
                        echo "<h1 class=\"titulo-perro\">Mis amigos perrunos</h1>";
                        for ($i=0; $i <$num_resultados; $i++) {
                            $row2 = mysqli_fetch_array($result); 
                            echo "<div class=\"blog-post\">
                                <div class=\"blog-post_img\">
                                    <img src=".$row2["Foto"]." class=\"img-blog\">
                                </div>
                                <div class=\"blog-post_info\">
                                    <h2 class=\"blog-post_title\"> Nombre: ".$row2['Nombre']."</h2>
                                    <h2 class=\"blog-post_title\"> Raza: ".$row2['Raza']."</h2> 
                                    "; if($row2['Genero'] == 1){
                                        echo "<h2 class=\"blog-post_title\"> Genero: MACHO</h2>";
                                        }else{
                                            echo "<h2 class=\"blog-post_title\"> Genero: HEMBRA</h2>";
                                        }
                            echo "<h2 class=\"blog-post_title\"> Fecha de Nacimiento: ".$row2['FechaNacimiento']."</h2> 
                                </div>
                            </div>";
                        }
                    }
                ?>
            </div>
    </section>
    
    <footer class="footer" id="Contacto">
        <div class="footer-content">
            <h3>Registro Local Canino</h3>
            <ul class="socials">
                <li><a href="#">
                    <i class='bx bxl-facebook-circle'></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-instagram-alt' ></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-twitch' ></i>
                </a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <p>copyright &copy;2021 Registro Local Canino. designed by <span>LosFs</span></p>
        </div>
    </footer>
</body>
</html>


    