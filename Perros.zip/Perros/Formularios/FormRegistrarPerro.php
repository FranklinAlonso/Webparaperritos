<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Perros</title>
    <link rel="stylesheet" href="../CSS/estilos_2.css">
</head>
<body>
    <header class="header-3">
        <div class="navigation">
            <?php
                $usuario = $_GET['variable'];
                $conn = mysqli_connect("localhost", "root","", "perrodb");
                if (!$conn) {
                    die("Error de conexion: " . mysqli_connect_error());
                }
                $query = mysqli_query($conn,"SELECT * FROM persona WHERE usuario = '".$usuario."'");
                $row = mysqli_fetch_array($query);
                echo "<a class=\"logo\"> Usuario: ".$row['Nombre'].", ".$row['Apellido']." </a>";
            ?>
            <!--a href="#" class="logo">Registro Local Canino</a-->
                <ul>
                    <li><a href="../Sesion/indexUsuario.php">Inicio</a></li>
                    <li><a href="FormConsultarPerro.php?variable=<?php echo $usuario; ?>">Consultar</a></li>
                    <li><a href="#Contacto">Contacto</a></li>
                </ul>
        </div>
        <!-- Formulario -->
        <form action="Registrar_Perro.php?variable=<?php echo $usuario; ?>" method="POST" class="form-register" enctype="multipart/form-data">
            <h4 >Registro Perruno</h4>
            <input name="nombre" type="text" class="controls" id="nombre" placeholder="Ingresar nombre del canino">
            <input name="fechNac" type="date" class="controls" id="fechNac" placeholder="Fecha de Nacimiento del canino">
            <div class="radio-boton"></div>
                <input value=1 type="radio" name="genero" id="macho">
                <label for="macho">Macho</label><br>
                <input value=0 type="radio" name="genero" id="hembra">
                <label for="hembra">Hembra</label><br>
            </div>
            <select class="controls" aria-label="Default select example" name="raza">
                <option selected>Seleccione Raza</option>
                <option value="Pitbull">Pitbull</option>
                <option value="Bulldog">Bulldog</option>
                <option value="Shichu">Shichu</option>
                <option value="Pequines">Pequines</option>
                <option value="SanBernardo">San Bernardo</option>
                <option value="Chiguahua">Chiguahua</option>
            </select>
            <!--<input name="foto" type="text" class="controls" id="foto" placeholder="Link de Foto">-->
            <input Type="file" name="imagen" id="imagen" class="camp">
            <button type="submit" class="botons">Registrar</button>
            <a href="../Sesion/indexUsuario.php" class="botons2">Regresar</a>
        </form>
    </header>
    <footer class="footer" id="Contacto">
        <div class="footer-content">
            <h3>Registro Local Canino</h3>
            <ul class="socials">
                <li><a href="#">
                    <i class='bx bxl-facebook-circle'></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-instagram-alt' ></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-twitch' ></i>
                </a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <p>copyright &copy;2021 Registro Local Canino. designed by <span>LosFs</span></p>
        </div>
    </footer>
</body>
</html>