<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar</title>
    <link rel="stylesheet" href="../css/estilos_2.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="header-2">
        <div class="navigation">
            <a href="#" class="logo">NOMBRE LOGO</a>
                <ul>
                    <li><a href="login.html">Ingresar</a></li>
                    <li><a href="#Contacto">Contacto</a></li>
                </ul>
        </div>
        <form action="signup.php" method="POST" class="form-register">
            <h4 >Registrar al Sistema</h4>
            <input name="nombre" type="text" class="controls" id="nombre" placeholder="Ingrese Nombre">
            <input name="apellido" type="text" class="controls" id="apellido" placeholder="Ingrese Apellido">
            <input name="DNI" type="text" class="controls" id="DNI" placeholder="Ingrese DNI">
            <input name="correo" type="text" class="controls" id="correo" placeholder="Ingrese Correo">
            <input name="usuario" type="text" class="controls" id="usuario" placeholder="Ingrese Usuario">
            <input name="clave" type="password" class="controls" id="clave" placeholder="Ingrese Contraseña">
            <input name="clave2" type="password" class="controls" id="clave2" placeholder="Confirma Contraseña">
            <button type="submit" class="botons">Registrar Usuario</button>
            <?php
            if(strlen($_POST['usuario']) >= 1 && strlen($_POST['clave']) >= 1 && strlen($_POST['clave2']) >= 1
            && strlen($_POST['nombre']) >= 1 && strlen($_POST['apellido']) >= 1 && strlen($_POST['DNI']) >= 1
            && strlen($_POST['correo']) >= 1){
                $conn = mysqli_connect("localhost", "root", "", "perrodb");
                if (!$conn) {
                    die("Error de conexion: " . mysqli_connect_error());
                }
                $name = $_POST["nombre"];
                $apellido = $_POST["apellido"];
                $dni = $_POST["DNI"];
                $correo = $_POST["correo"];
                $nombre = $_POST["usuario"];
                $clave = $_POST["clave"];
                $verificacion = $_POST["clave2"];
                $query = mysqli_query($conn,"SELECT * FROM persona WHERE usuario = '".$nombre."'");
                $nr = mysqli_num_rows($query);
                if($nr == 1){
                    ?>
                        <p>¡Ya existe ese Usuario!</p>
                    <?php
                }else{
                    if(strcmp($clave,$verificacion) == 0){
                        $sql ="INSERT INTO persona (Nombre, Apellido, DNI, Correo, usuario, clave) VALUES ('$name','$apellido','$dni','$correo','$nombre','$clave')";
                        $resultado= mysqli_query($conn, $sql);
                        if(!$resultado){
                            ?>
                                <p>¡No se logro realizar el registro!</p>
                            <?php
                        }else{
                            ?> 
                                <p>¡Se ha registrado exitosamente!</p>
                            <?php
                        }
                    }else{
                        ?> 
                            <p>¡No coincide la contraseña de confirmacion!</p>
                        <?php
                    }
                }
            }else{
                ?> 
                    <p>¡Por favor ingrese los datos!</p>
                <?php
            }
            ?>
        </form>
    </header>
    <footer class="footer" id="Contacto">
        <div class="footer-content">
            <h3>Registro Local Canino</h3>
            <ul class="socials">
                <li><a href="#">
                    <i class='bx bxl-facebook-circle'></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-instagram-alt' ></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-twitch' ></i>
                </a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <p>copyright &copy;2021 Registro Local Canino. designed by <span>LosFs</span></p>
        </div>
    </footer>
</body>
</html>