<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loguear</title>
    <link rel="stylesheet" href="../css/estilos_2.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="header">
        <div class="navigation">
            <a href="#" class="logo">Registro Local Canino</a>
                <ul>
                    <li><a href="login.html">Ingresar</a></li>
                    <li><a href="#Contacto">Contacto</a></li>
                </ul>
        </div>
        <form method="post" action="login.php" class="form-register" id="Ingresar">
            <h4 >Ingresar al Sistema</h4>
            <input type="text" name="txtusuario" class="controls" id="usuario" placeholder="Ingresar su Usuario">
            <input type="password" name="txtpassword" class="controls" id="password" placeholder="Ingresar su Contraseña">
            <button type="submit" class="botons">Ingresar</button>
            <!--input type="submit" name="Ingresar" value="Ingresar"-->
            <p>¿Aun no esta Registrado?<a href="signup.html" class="botons2"> Registrar</a></p>
            <?php
            session_start();
            if(strlen($_POST['txtusuario']) >= 1 && strlen($_POST['txtpassword']) >= 1 ){
                $conn = mysqli_connect("localhost", "root","", "perrodb");
                if (!$conn) {
                    die("Error de conexion: " . mysqli_connect_error());
                }
                $nombre = $_POST["txtusuario"];
                $pass = $_POST["txtpassword"];
                //$query = mysqli_query($conn,"SELECT * FROM persona WHERE usuario = '".$nombre."' and clave = '".$pass."'");
                $query = mysqli_query($conn,"SELECT * FROM persona WHERE usuario = '".$nombre."'");
                $nr = mysqli_num_rows($query);
                $row = mysqli_fetch_array($query);
                if($nr == 1){
                    if(strcmp($row["clave"],$pass) == 0){
                        $_SESSION['usuario'] = $nombre;
                        header("location: indexUsuario.php");
                    }else{
                        ?> 
                            <p>¡Datos incorrecto!*</p>
                        <?php
                    }
                    
                }else{
                        ?> 
                            <p>¡No esta Registradoooo ese Usuario!*</p>
                        <?php
                }
            }else{
                    ?> 
                        <p>¡Porfavor ingrese los datos!*</p>
                    <?php
            }
            ?>
        </form>
    </header>
    <footer class="footer" id="Contacto">
        <div class="footer-content">
            <h3>Registro Local Canino</h3>
            <ul class="socials">
                <li><a href="#">
                    <i class='bx bxl-facebook-circle'></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-instagram-alt' ></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-twitch' ></i>
                </a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <p>copyright &copy;2021 Registro Local Canino. designed by <span>LosFs</span></p>
        </div>
    </footer>
</body>
</html>