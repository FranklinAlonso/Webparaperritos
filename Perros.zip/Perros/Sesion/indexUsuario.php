<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro local Canino</title>
    <link rel="stylesheet" href="../css/estilos_1.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;700&display=swap" rel="stylesheet">
</head>
<body>
    
    <header class="header">
        <div class="navigation">
            <a href="#" class="logo">Registro Local Canino</a>
                <ul>
                    <li><a href="#Nosotros">Nosotros</a></li>
                    <li><a href="">Servicios</a></li>
                    <li><a href="#Contacto">Contacto</a></li>
                    <li><a href="../index.html">Cerrar Sesion</a></li>
                </ul>
        </div>
        <section class="contenido">
            <h1>Registra a tu amigo Canino</h1>
            <?php
                session_start();
                $usuario = $_SESSION['usuario'];
                $conn = mysqli_connect("localhost", "root","", "perrodb");
                if (!$conn) {
                    die("Error de conexion: " . mysqli_connect_error());
                }
                $query = mysqli_query($conn,"SELECT * FROM persona WHERE usuario = '".$usuario."'");
                $row = mysqli_fetch_array($query);
                echo "<p> Bienvenido ".$row['Nombre'].", ".$row['Apellido']." </p>";
            ?>
            <div>
                <a href="../Formularios/FormRegistrarPerro.php?variable=<?php echo $usuario; ?>" class="botones"><span></span>Registrar</a>
                <a href="../Formularios/FormConsultarPerro.php?variable=<?php echo $usuario; ?>" class="botones"><span></span>Consultar</a>
            </div>
        </section>
    </header>
    <div class="curva"></div>
    <section class="informacion">
        <div class="container resena">
            <div class="card-reu">
                <div class="blog-post">
                    <div class="blog-post_img">
                        <img src="../img/dog_papu (1).png" alt="" class="img-blog">
                    </div>
                    <div class="blog-post_info">
                        <h1 class="blog-post_title">Registrar Perro</h1>
                        <p class="blog-post_text">Se podra registrar al perro con sus respectivos datos entre nombre, sexo, raza y fecha de nacimiento. 
                        </p>
                        <a href="../Formularios/FormRegistrarPerro.php?variable=<?php echo $usuario; ?>" target="" class="blog-post_cta">Registrar</a>
                    </div>
                </div>
                <div class="blog-post">
                    <div class="blog-post_img">
                        <img src="../img/dog_papu.png" alt="" class="img-blog">
                    </div>
                    <div class="blog-post_info">
                        <h1 class="blog-post_title">Consultar Perro</h1>
                        <p class="blog-post_text">Se podra consultar la informacion de cualquier perro por su nombre.
                        </p>
                        <a href="../Formularios/FormConsultarPerro.php?variable=<?php echo $usuario; ?>" target="" class="blog-post_cta">Consultar</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <footer class="footer">
        <div class="footer-content">
            <h3>Registro Local Canino</h3>
            <ul class="socials">
                <li><a href="#">
                    <i class='bx bxl-facebook-circle'></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-instagram-alt' ></i>
                </a></li>
                <li><a href="#">
                    <i class='bx bxl-twitch' ></i>
                </a></li>
            </ul>
        </div>
        <div class="footer-bottom">
            <p>copyright &copy;2021 Registro Local Canino. designed by <span>LosFs</span></p>
        </div>
    </footer>
</body>
</html>